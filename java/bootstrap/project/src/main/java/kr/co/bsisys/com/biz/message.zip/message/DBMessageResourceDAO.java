package kr.co.bsisys.com.biz.message;

import java.util.List;

public interface DBMessageResourceDAO {
  
  List<DBMessageVO> findDBMessages();
  
}
