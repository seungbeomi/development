/**
 * Copyright (c) 2013 BS Information System
 */
package kr.co.bsisys.com.biz.code;

import static kr.co.bsisys.fw.util.StringUtil.EMPTY;
import kr.co.bsisys.fw.vo.VO;

/**
 * 공통코드리스트 클래스
 * 
 * @since 2013. 5. 5.
 * @author BS정보시스템/손승범
 */
public class ComCodeDetailVO extends VO {
  
  private String codeId;
  private String code;
  private String codeNm;
  private String sort;
  private String useYn;
  
  public String getCodeId() {
    return codeId;
  }
  
  public void setCodeId(String codeId) {
    this.codeId = codeId;
  }
  
  public String getCode() {
    return code;
  }
  
  public void setCode(String code) {
    this.code = (code == null) ? EMPTY : code;
  }
  
  public String getCodeNm() {
    return codeNm;
  }
  
  public void setCodeNm(String codeNm) {
    this.codeNm = (codeNm == null) ? EMPTY : codeNm;
  }
  
  public String getSort() {
    return sort;
  }
  
  public void setSort(String sort) {
    this.sort = sort;
  }
  
  /**
   * @return the useYn
   */
  public String getUseYn() {
    return useYn;
  }
  
  /**
   * @param useYn the useYn to set
   */
  public void setUseYn(String useYn) {
    this.useYn = useYn;
  }
  
  public String getLabel() {
    return code + " " + codeNm;
  }
  
  public String getCodeCommaCodeNm() {
    return code + "," + codeNm;
  }
  
  @Override
  public String toString() {
    return "CodeList [codeId=" + codeId + ", code=" + code + ", codeNm="
        + codeNm + ", sort=" + sort + ", useYn=" + useYn + "]";
  }
  
}
