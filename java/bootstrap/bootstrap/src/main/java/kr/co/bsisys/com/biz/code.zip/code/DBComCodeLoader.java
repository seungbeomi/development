/**
 * Copyright (c) 2013 BS Information System
 */
package kr.co.bsisys.com.biz.code;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import kr.co.bsisys.fw.util.AssertUtil;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.object.MappingSqlQuery;

/**
 * 
 * @since 2013. 5. 5.
 * @author BS정보시스템/손승범
 */
public class DBComCodeLoader implements ReloadableComCodeLoader {
  
  private static final Logger logger = LoggerFactory.getLogger(DBComCodeLoader.class);
  
  private Map<String, List<ComCodeDetailVO>> codeListMap = null;
  
  /* 공통코드조회쿼리 */
  public static final String DEF_CODE_ID_LIST_QUERY =
      "/* DBCodeListLoader.DEF_CODE_ID_LIST_QUERY */ " +
          "SELECT MSTR_CD, MSTR_CD_NM " +
          "FROM   CMM_CD " +
          "WHERE  USE_YN = 'Y' " +
          "ORDER  BY MSTR_CD";
  
  /* 공통코드상세조회쿼리 */
  public static final String DEF_CODE_LIST_QUERY =
      "/* DBCodeListLoader.DEF_CODE_LIST_QUERY */ " +
          "SELECT A.MSTR_CD, B.DTL_CD, B.DTL_CD_NM, B.DTL_CD_SORT " +
          "FROM   CMM_CD A, CMM_CD_DTL B " +
          "WHERE  A.MSTR_CD = B.MSTR_CD " +
          "AND    A.USE_YN = 'Y' " +
          "AND    B.USE_YN = 'Y' " +
          "ORDER  BY A.MSTR_CD, B.DTL_CD_SORT";
  
  private String codeListIdQuery;
  private String codeListQuery;
  
  private DataSource dataSource = null;
  
  private final Object lockObject = new Object();
  
  public DBComCodeLoader() {
    this.codeListIdQuery = DEF_CODE_ID_LIST_QUERY;
    this.codeListQuery = DEF_CODE_LIST_QUERY;
  }
  
  public void load() {
    logger.debug("load() called.");
    
    if (codeListMap != null) {
      return;
    }
    loadCodeList();
  }
  
  public void reload() {
    logger.debug("reload() called.");
    
    if (codeListMap == null) {
      loadCodeList();
    } else {
      synchronized (lockObject) {
        loadCodeList();
      }
    }
  }
  
  protected void loadCodeList() {
    logger.debug("loadCodeList() called.");
    
    // 부모 코드리스트
    MappingSqlQuery<ComCodeVO> codeIdListSqlQuery = new DBComCodeQuery(
        dataSource, codeListIdQuery);
    codeIdListSqlQuery.compile();
    List<ComCodeVO> comCodeList = codeIdListSqlQuery.execute();
    
    // 자식 코드리스트
    MappingSqlQuery<ComCodeDetailVO> CodeListSqlQuery = new DBComCodeDetailQuery(dataSource, codeListQuery);
    CodeListSqlQuery.compile();
    List<ComCodeDetailVO> CodeLists = CodeListSqlQuery.execute();
    
    Map<String, List<ComCodeDetailVO>> resultMap = new HashMap<String, List<ComCodeDetailVO>>();
    StringBuffer sb = new StringBuffer();
    
    if (logger.isDebugEnabled()) {
      sb.append("\n\n  [DBCodeListLoader]");
    }
    
    for (ComCodeVO cil : comCodeList) {
      String codeId = cil.getCodeId();
      String codeIdNm = cil.getCodeIdNm();
      
      if (logger.isDebugEnabled()) {
        sb.append("\n    [" + codeId + "] : " + codeIdNm);
      }
      
      List<ComCodeDetailVO> list = new ArrayList<ComCodeDetailVO>();
      for (ComCodeDetailVO cl : CodeLists) {
        if (codeId.equals(cl.getCodeId())) {
          if (logger.isDebugEnabled()) {
            sb.append("\n      " + cl);
          }
          list.add(cl);
        }
      }
      resultMap.put(codeId, list);
    }
    if (logger.isDebugEnabled()) {
      sb.append("\n");
    }
    logger.debug(sb.toString());
    
    codeListMap = Collections.unmodifiableMap(resultMap);
  }
  
  @Override
  public List<ComCodeDetailVO> getCodeList(String codeId) {
    AssertUtil.notNull(codeId);
    
    List<ComCodeDetailVO> codeListList = codeListMap.get(codeId);
    
    if (codeListList == null) {
      return new ArrayList<ComCodeDetailVO>();
    } else {
      return codeListList;
    }
  }
  
  @Override
  public Map<String, List<ComCodeDetailVO>> getCodeListMap() {
    if (codeListMap == null) {
      return new HashMap<String, List<ComCodeDetailVO>>();
    } else {
      return codeListMap;
    }
  }
  
  // ////////////////////////////////////////////////////////////////////
  // setter, getter
  public DataSource getDataSource() {
    return dataSource;
  }
  
  public void setDataSource(DataSource dataSource) {
    this.dataSource = dataSource;
  }
  
  public String getCodeListIdQuery() {
    return codeListIdQuery;
  }
  
  public void setCodeListIdQuery(String codeListIdQuery) {
    this.codeListIdQuery = codeListIdQuery;
  }
  
  public String getCodeListQuery() {
    return codeListQuery;
  }
  
  public void setCodeListQuery(String codeListQuery) {
    this.codeListQuery = codeListQuery;
  }
  
}
