/**
 * Copyright (c) 2013 BS Information System
 */
package kr.co.bsisys.com.biz.code;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/**
 * 
 * @since 2013. 5. 5.
 * @author BS정보시스템/손승범
 */
public class MappedComCodeLoader implements ComCodeLoader {
  
  private Map<String, String> codeListMap = null;
  private List<ComCodeDetailVO> codeLists = null;
  
  public Map<String, String> getCodeListMap() {
    return codeListMap;
  }
  
  public void setCodeListMap(Map<String, String> codeListMap) {
    this.codeListMap = codeListMap;
  }
  
  public void load() {
    if (codeLists != null) {
      return;
    }
    if (codeListMap == null) {
      codeLists = Collections.unmodifiableList(new ArrayList<ComCodeDetailVO>());
      return;
    }
    List<ComCodeDetailVO> list = new ArrayList<ComCodeDetailVO>();
    Iterator<String> iter = codeListMap.keySet().iterator();
    while (iter.hasNext()) {
      String code = (String) iter.next();
      String name = codeListMap.get(code);
      ComCodeDetailVO cb = new ComCodeDetailVO();
      cb.setCode(code);
      cb.setCodeNm(name);
      list.add(cb);
    }
    codeLists = Collections.unmodifiableList(list);
  }
  
  @Override
  public List<ComCodeDetailVO> getComCodeDetailList() {
    if (codeLists == null) {
      return new ArrayList<ComCodeDetailVO>();
    }
    return codeLists;
  }
  
}
