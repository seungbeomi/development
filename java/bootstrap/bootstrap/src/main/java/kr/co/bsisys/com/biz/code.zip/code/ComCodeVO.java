/**
 * Copyright (c) 2013 BS Information System
 */
package kr.co.bsisys.com.biz.code;

import kr.co.bsisys.fw.vo.VO;

/**
 * 
 * @since 2013. 5. 5.
 * @author BS정보시스템/손승범
 */
public class ComCodeVO extends VO {
  
  private String codeId;
  private String codeIdNm;
  private String useAt;
  
  public String getCodeId() {
    return codeId;
  }
  
  public void setCodeId(String codeId) {
    this.codeId = codeId;
  }
  
  public String getCodeIdNm() {
    return codeIdNm;
  }
  
  public void setCodeIdNm(String codeIdNm) {
    this.codeIdNm = codeIdNm;
  }
  
  public String getUseAt() {
    return useAt;
  }
  
  public void setUseAt(String useAt) {
    this.useAt = useAt;
  }
  
}
