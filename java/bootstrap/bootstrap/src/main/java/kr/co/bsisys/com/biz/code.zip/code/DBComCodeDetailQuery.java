/**
 * Copyright (c) 2013 BS Information System
 */
package kr.co.bsisys.com.biz.code;

import java.sql.ResultSet;
import java.sql.SQLException;

import javax.sql.DataSource;

import org.springframework.jdbc.object.MappingSqlQuery;

/**
 * 
 * @since 2013. 5. 5.
 * @author BS정보시스템/손승범
 */
public class DBComCodeDetailQuery extends MappingSqlQuery<ComCodeDetailVO> {
  
  public DBComCodeDetailQuery(DataSource dataSource, String sql) {
    super(dataSource, sql);
  }
  
  @Override
  protected ComCodeDetailVO mapRow(ResultSet rs, int rowNum) throws SQLException {
    return createCodeList(rs);
  }
  
  private ComCodeDetailVO createCodeList(ResultSet rs) throws SQLException {
    
    ComCodeDetailVO codeList = new ComCodeDetailVO();
    
    int columnCount = rs.getMetaData().getColumnCount();
    
    if (columnCount > 0) {
      String codeId = rs.getString(1);
      if (codeId == null) {
        codeId = "";
      }
      codeList.setCodeId(codeId);
    }
    if (columnCount > 1) {
      String code = rs.getString(2);
      if (code == null) {
        code = "";
      }
      codeList.setCode(code);
    }
    if (columnCount > 2) {
      String codeNm = rs.getString(3);
      if (codeNm == null) {
        codeNm = "";
      }
      codeList.setCodeNm(codeNm);
    }
    if (columnCount > 3) {
      String sort = rs.getString(4);
      if (sort == null) {
        sort = "";
      }
      codeList.setSort(sort);
    }
    return codeList;
  }
  
}
