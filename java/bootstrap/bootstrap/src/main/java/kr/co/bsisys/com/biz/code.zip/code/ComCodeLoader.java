/**
 * Copyright (c) 2013 BS Information System
 */
package kr.co.bsisys.com.biz.code;

import java.util.List;

/**
 * 
 * @since 2013. 5. 5.
 * @author BS정보시스템/손승범
 */
public interface ComCodeLoader {
  
  void load();
  
  List<ComCodeDetailVO> getComCodeDetailList();
  
}
