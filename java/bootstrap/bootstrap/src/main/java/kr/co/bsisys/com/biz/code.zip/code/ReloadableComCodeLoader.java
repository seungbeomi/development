/**
 * Copyright (c) 2013 BS Information System
 */
package kr.co.bsisys.com.biz.code;

import java.util.List;
import java.util.Map;

/**
 * 
 * @since 2013. 5. 5.
 * @author BS정보시스템/손승범
 */
public interface ReloadableComCodeLoader {
  
  void load();
  
  void reload();
  
  List<ComCodeDetailVO> getCodeList(String codeId);
  
  Map<String, List<ComCodeDetailVO>> getCodeListMap();
  
}
