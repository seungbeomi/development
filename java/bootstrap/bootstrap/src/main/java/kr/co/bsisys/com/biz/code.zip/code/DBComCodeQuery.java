/**
 * Copyright (c) 2013 BS Information System
 */
package kr.co.bsisys.com.biz.code;

import java.sql.ResultSet;
import java.sql.SQLException;

import javax.sql.DataSource;

import org.springframework.jdbc.object.MappingSqlQuery;

/**
 * 
 * @since 2013. 5. 5.
 * @author BS정보시스템/손승범
 */
public class DBComCodeQuery extends MappingSqlQuery<ComCodeVO> {
  
  public DBComCodeQuery(DataSource dataSource, String sql) {
    super(dataSource, sql);
  }
  
  @Override
  protected ComCodeVO mapRow(ResultSet rs, int rowNum) throws SQLException {
    return createCodeList(rs);
  }
  
  private ComCodeVO createCodeList(ResultSet rs) throws SQLException {
    
    ComCodeVO codeIdList = new ComCodeVO();
    
    int columnCount = rs.getMetaData().getColumnCount();
    
    if (columnCount > 0) {
      String codeId = rs.getString(1);
      if (codeId == null) {
        codeId = "";
      }
      codeIdList.setCodeId(codeId);
    }
    if (columnCount > 1) {
      String codeIdNm = rs.getString(2);
      if (codeIdNm == null) {
        codeIdNm = "";
      }
      codeIdList.setCodeIdNm(codeIdNm);
    }
    return codeIdList;
  }
  
}
