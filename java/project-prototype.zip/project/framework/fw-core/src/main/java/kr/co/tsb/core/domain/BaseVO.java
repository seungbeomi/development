package kr.co.tsb.core.domain;

import java.io.Serializable;

public class BaseVO implements Serializable {

}
