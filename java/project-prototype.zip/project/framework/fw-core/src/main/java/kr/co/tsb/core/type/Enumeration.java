package kr.co.tsb.core.type;

public interface Enumeration {

	String getCode();
	
	Object getValue();
	
	int getOrder();
}
