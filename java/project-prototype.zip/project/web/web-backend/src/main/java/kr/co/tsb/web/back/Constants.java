package kr.co.tsb.web.back;

public class Constants implements kr.co.tsb.core.Constants,
								  kr.co.tsb.comp.batch.admin.Constants {

}
