package kr.co.tsb.web.front;

public class Constants implements kr.co.tsb.core.Constants {

}
