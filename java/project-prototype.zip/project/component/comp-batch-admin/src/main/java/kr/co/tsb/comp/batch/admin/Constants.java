package kr.co.tsb.comp.batch.admin;

public interface Constants extends kr.co.tsb.core.Constants {

}
